/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labsheet1;
import java.awt.*;
/**
 *
 * @M 
 */
public class FirstGUI {
    public FirstGUI(){
        Frame f=new Frame();
        f.setTitle("My Frist GUI Program");
        f.setSize(600,400);
        f.setVisible(true);
        f.setLayout(null);
    }
    public static void main(String[] args){
        FirstGUI obj1=new FirstGUI();
    }
}
